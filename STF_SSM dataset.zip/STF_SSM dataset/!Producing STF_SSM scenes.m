%%%% Auther of the STF_SSM dataset is Haoxuan Yang, Jia Yang, Tyson E. Ochsner
%%%% The STF_SSM dataset is generated using the VIPSTF-SW method
%%%% Auther of the VIPSTF-SW method is Qunming Wang
%%%% When using the code, please cite the following papers
%%%% Haoxuan Yang et al. A 3-hour, 1-km surface soil moisture dataset for the contiguous United States from 2015 to 2023. Earth System Science Data Discussion, 2025. 
%%%% Qunming Wang et al. Virtual image pair-based spatio-temporal fusion. Remote Sensing of Environment, 2020, 249: 112009.



clear all;clc;
filepath='D:\OSU\research1\1km_surface_SMAP\1_km_mask\1km_mask';
[Data, R] = geotiffread(filepath);
info=geotiffinfo('D:\OSU\research1\1km_surface_SMAP\1_km_mask\1km_mask');
datadir = 'D:\OSU\research1\3_hourly_SMAP\composite_1km_SSM\2022\characteristic\';  %% fine characteristics
datadir2 = 'D:\OSU\research1\3_hourly_SMAP\composite_SMAP4\2022\SSM\characteristic\';  %% coarse characteristics
filelist = dir([datadir,'*.tif']); 
filelist2 = dir([datadir2,'*.tif']);
k=length(filelist);
j=1;
for i = 1:4;
    filename1 = ['D:\OSU\research1\3_hourly_SMAP\composite_1km_SSM\2022\characteristic\',filelist(i).name];   %% fine
    filename2 = ['D:\OSU\research1\3_hourly_SMAP\composite_SMAP4\2022\SSM\characteristic\',filelist2(i).name];  %% coarse
    A_num = double(imread(filename1));
    B_num = double(imread(filename2));
    A_num(A_num>=0.6)=0.6;
    B_num(B_num>=0.6)=0.6;
    fine_input(:,:,j) = A_num;
    coarse_input(:,:,j) = B_num;
    j=j+1;
end
datadir3 = 'D:\OSU\research1\3_hourly_SMAP\USA_smap4\2022\SSM\'; %% 3-hour SMAP scenes
filelist3 = dir([datadir3,'*.tif']);
k=length(filelist3);
time = [];


j=1;
fk = 1;
for iis = 1:k ;
    tic
    filename3 = ['D:\OSU\research1\3_hourly_SMAP\USA_smap4\2022\SSM\',filelist3(iis).name]; 
    C_num = double(imread(filename3));
    C_num(C_num<=0)=0;
    C_num(C_num>=0.6)=0.6;
    C_num(find(isnan(C_num)==1)) = 0;
    num = filelist3(iis).name(9:22);
    L1 = fine_input;
    L2 = fine_input(:,:,1);
    M1 = coarse_input;
    M2 = C_num;
    w=3;
    N_S=5;
    A=(2*w+1)/2;
    Z2=zeros(size(L2));
    %VIP_STARFM
    [a1,b1,c1]=size(M1);
    [a2,b2,c2]=size(L1);
    s=a2/a1;
    GB0=D3_D2(M1);
    GB1=reshape(M2,1,a1*b1);
    GB2=[GB1;GB0];
    j=1;
    for i=1:size(GB2,2)
        if GB2(:,i)~=0
            new_GB2(:,j)= GB2(:,i);
            j=j+1;
        else
            continue;
        end
    end
    N_GB1=new_GB2(1,:);
    N_GB0=new_GB2(2:end,:);
    xrc1=lsqlin([ones(numel(N_GB1),1),N_GB0'],N_GB1,[],[]) ;
    GBF=D3_D2(L1);
    Ff1=[ones(a2*b2,1),GBF']*xrc1;L2_VIP=reshape(Ff1,a1*s,b1*s);
    Ff2=[ones(a1*b1,1),GB0']*xrc1;M2_VIP=reshape(Ff2,a1,b1);
    maskexM2 = M2>0;
    se = strel("square",7);
    dilated_mask = imdilate(maskexM2,se);
    extension_region = dilated_mask & ~maskexM2;
    padded_A = padarray(M2,[3 3],'replicate');
    window_size = 7;
    avg_filter = ones(window_size)/window_size^2;
    average_A = conv2(padded_A,avg_filter,'same');
    average_A = average_A(4:end-3, 4:end-3);
    M2(extension_region) = average_A(extension_region);
    x=M2_VIP(:,:);
    y=M2(:,:);
    Diff_bicubic(:,:)=imresize(y-x,s,'bicubic');
    Z_Diff=STARFM_fast_2016_v2(Z2,Z2,Diff_bicubic,L2_VIP,L2_VIP,w,N_S,A);
    VIP_STARFM=L2_VIP+Z_Diff;
    VIP_STARFM(VIP_STARFM<=0)=0;
    background=imresize(M2,s,'bicubic');
    judge_back=double(VIP_STARFM<=0);
    VIP_STARFM=judge_back.*background+VIP_STARFM;
    mask=imread('D:\OSU\research1\1km_prep\mask\1km_mask.tif');
    extend1 = mask(1:4,:);
    mask1 = [extend1;extend1;mask];
    extend2 = mask1(:,4609:end);
    mask2 = [mask1,extend2,extend2];
    judge_mask=double(mask2>0);
    VIP_STARFM=judge_mask.*VIP_STARFM;
    VIP_STARFM1 = VIP_STARFM(9:end,:);
    VIP_STARFM2 = VIP_STARFM1(:,1:4611);
    VIP_STARFM2(VIP_STARFM2>=0.6)=0.6;
    geotiffwrite(['D:\OSU\research1\3_hourly_SMAP\fused_1km_SSM\2022\SSM\VIP_1km_' num2str(num) '.tif'],VIP_STARFM2,R, 'GeoKeyDirectoryTag', info.GeoTIFFTags.GeoKeyDirectoryTag);
    alltime=toc
    time(fk,1) = alltime;
    fk = fk+1;
end

